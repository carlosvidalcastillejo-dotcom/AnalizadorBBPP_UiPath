"""
Ventana principal de la aplicación
UI con Tkinter (sin necesidad de instalación adicional)
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import sys

# Agregar src al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.config import (
    WINDOW_TITLE, WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT,
    PRIMARY_COLOR, SECONDARY_COLOR, BG_COLOR, TEXT_COLOR, ACCENT_COLOR, COLOR_ERROR,
    APP_VERSION, APP_VERSION_TYPE, APP_AUTHOR, COMPANY,
    load_user_config, save_user_config, reset_to_defaults,
    get_threshold, set_threshold, get_validation_option, set_validation_option,
    get_output_option, set_output_option, get_custom_logo, set_custom_logo,
    DEFAULT_CONFIG, COLOR_SUCCESS
)

class MainWindow:
    """Ventana principal de la aplicación"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(WINDOW_TITLE)
        self.root.geometry(f"{WINDOW_MIN_WIDTH}x{WINDOW_MIN_HEIGHT}")
        self.root.minsize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
        
        self.project_path = None
        
        self._setup_ui()
        
    def _setup_ui(self):
        """Configurar la interfaz de usuario"""
        # Barra de estado (PRIMERO para que ocupe todo el ancho abajo)
        self._create_status_bar()

        # Menú lateral
        self._create_sidebar()
        
        # Área principal
        self._create_main_area()
        
    def _create_sidebar(self):
        """Crear menú lateral"""
        sidebar = tk.Frame(self.root, bg=PRIMARY_COLOR, width=200)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)
        sidebar.pack_propagate(False)
        
        # Título de la aplicación
        title_label = tk.Label(
            sidebar,
            text="Analizador BBPP\nUiPath",
            bg=PRIMARY_COLOR,
            fg="white",
            font=("Arial", 16, "bold"),
            pady=20
        )
        title_label.pack()
        
        # Versión
        version_label = tk.Label(
            sidebar,
            text=f"v{APP_VERSION} {APP_VERSION_TYPE}",
            bg=PRIMARY_COLOR,
            fg="white",
            font=("Arial", 9)
        )
        version_label.pack()
        
        # Separador
        separator = tk.Frame(sidebar, bg="white", height=2)
        separator.pack(fill=tk.X, padx=20, pady=20)
        
        # Botones del menú
        self._create_menu_button(sidebar, "📊 Análisis", self._show_analysis_screen)
        self._create_menu_button(sidebar, "📋 Gestión de BBPP", self._show_bbpp_management_screen)
        self._create_menu_button(sidebar, "⚙️ Configuración", self._show_config_screen)
        self._create_menu_button(sidebar, "📈 Métricas", self._show_metrics_dashboard)
        self._create_menu_button(sidebar, "📝 Notas de Versión", self._show_version_notes)
        
        # Espaciador
        tk.Frame(sidebar, bg=PRIMARY_COLOR).pack(fill=tk.BOTH, expand=True)
        
        # Botón salir al final
        exit_btn = tk.Button(
            sidebar,
            text="🚪 Salir",
            command=self.root.quit,
            bg="#DC3545",
            fg="white",
            font=("Arial", 11),
            relief=tk.FLAT,
            cursor="hand2",
            pady=10
        )
        exit_btn.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        
        # Logo/Texto de empresa (personalizable)
        try:
            from src.branding_manager import get_company_name
            company_text = get_company_name()
        except ImportError:
            company_text = COMPANY
        
        company_label = tk.Label(
            sidebar,
            text=company_text,
            bg=PRIMARY_COLOR,
            fg="white",
            font=("Arial", 10, "bold")
        )
        company_label.pack(side=tk.BOTTOM, pady=10)
        
    def _create_menu_button(self, parent, text, command):
        """Crear botón del menú"""
        btn = tk.Button(
            parent,
            text=text,
            command=command,
            bg=SECONDARY_COLOR,
            fg="white",
            font=("Arial", 11),
            relief=tk.FLAT,
            cursor="hand2",
            pady=10,
            anchor="w",
            padx=20
        )
        btn.pack(fill=tk.X, padx=10, pady=5)
        
        # Efecto hover
        btn.bind("<Enter>", lambda e: btn.config(bg="#0090D1"))
        btn.bind("<Leave>", lambda e: btn.config(bg=SECONDARY_COLOR))
        
        return btn
    
    def _create_main_area(self):
        """Crear área principal"""
        self.main_area = tk.Frame(self.root, bg=BG_COLOR)
        self.main_area.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # Por defecto, mostrar pantalla de análisis
        self._show_analysis_screen()
        
    def _create_status_bar(self):
        """Crear barra de estado estilo SAP"""
        self.status_bar_frame = tk.Frame(self.root, bd=1, relief=tk.SUNKEN, bg="#F0F0F0")
        self.status_bar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_label = tk.Label(
            self.status_bar_frame,
            text="Listo",
            bg="#F0F0F0",
            fg="black",
            anchor=tk.W,
            padx=10,
            pady=2
        )
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
    def update_status(self, message, type='info'):
        """Actualizar mensaje en barra de estado"""
        color = "black"
        if type == 'error':
            color = "red"
        elif type == 'success':
            color = "green"
        elif type == 'warning':
            color = "#FF8C00"  # Dark Orange
            
        self.status_label.config(text=message, fg=color)
        self.root.update_idletasks()
    
    def _clear_main_area(self):
        """Limpiar área principal"""
        for widget in self.main_area.winfo_children():
            widget.destroy()
    
    # ========================================================================
    # PANTALLAS
    # ========================================================================
    
    def _show_analysis_screen(self):
        """Mostrar pantalla de análisis"""
        self._clear_main_area()
        
        # Título
        title = tk.Label(
            self.main_area,
            text="Análisis de Buenas Prácticas",
            font=("Arial", 18, "bold"),
            bg=BG_COLOR,
            fg=TEXT_COLOR
        )
        title.pack(pady=20)
        
        # Frame para selección de proyecto
        project_frame = tk.LabelFrame(
            self.main_area,
            text="Seleccionar Proyecto UiPath",
            font=("Arial", 12, "bold"),
            bg=BG_COLOR,
            padx=20,
            pady=20
        )
        project_frame.pack(padx=20, pady=10, fill=tk.X)
        
        # Entrada de ruta
        path_frame = tk.Frame(project_frame, bg=BG_COLOR)
        path_frame.pack(fill=tk.X)
        
        self.path_entry = tk.Entry(
            path_frame,
            font=("Arial", 11),
            width=50
        )
        self.path_entry.pack(side=tk.LEFT, padx=(0, 10), fill=tk.X, expand=True)
        
        browse_btn = tk.Button(
            path_frame,
            text="Examinar...",
            command=self._browse_project,
            bg=SECONDARY_COLOR,
            fg="white",
            font=("Arial", 10, "bold"),
            cursor="hand2"
        )
        browse_btn.pack(side=tk.LEFT)

        # Frame para selección de reglas
        rules_frame = tk.LabelFrame(
            self.main_area,
            text="Conjunto de Reglas",
            font=("Arial", 12, "bold"),
            bg=BG_COLOR,
            padx=20,
            pady=20
        )
        rules_frame.pack(padx=20, pady=10, fill=tk.X)
        
        # Cargar sets disponibles
        try:
            from src.rules_manager import get_rules_manager
            rm = get_rules_manager()
            sets = rm.get_available_sets()
            set_names = [s['name'] for s in sets]
        except Exception:
            set_names = ["UiPath", "NTTData"]
        
        # Combobox
        tk.Label(rules_frame, text="Seleccionar reglas a aplicar:", bg=BG_COLOR, font=("Arial", 10)).pack(anchor="w")
        self.rules_combo = ttk.Combobox(rules_frame, values=["Todas"] + set_names, state="readonly", font=("Arial", 10))
        self.rules_combo.set("Todas")
        self.rules_combo.pack(fill=tk.X, pady=5)

        # Botón de análisis
        analyze_btn = tk.Button(
            self.main_area,
            text="🔍 INICIAR ANÁLISIS",
            command=self._start_analysis,
            bg=PRIMARY_COLOR,
            fg="white",
            font=("Arial", 14, "bold"),
            cursor="hand2",
            pady=15,
            padx=40
        )
        analyze_btn.pack(pady=30)
        
        # Frame para botones de reportes
        reports_frame = tk.Frame(self.main_area, bg=BG_COLOR)
        reports_frame.pack(pady=5)
        
        # Botón para generar reporte HTML
        self.report_btn = tk.Button(
            reports_frame,
            text="📄 Generar HTML",
            command=self._generate_report,
            bg=SECONDARY_COLOR,
            fg="white",
            font=("Arial", 11, "bold"),
            cursor="hand2",
            pady=8,
            padx=20,
            state=tk.DISABLED
        )
        self.report_btn.pack(side=tk.LEFT, padx=5)
        
        # Botón para generar reporte Excel
        self.excel_btn = tk.Button(
            reports_frame,
            text="📊 Generar Excel",
            command=self._generate_excel_report,
            bg="#217346",  # Verde Excel
            fg="white",
            font=("Arial", 11, "bold"),
            cursor="hand2",
            pady=8,
            padx=20,
            state=tk.DISABLED
        )
        self.excel_btn.pack(side=tk.LEFT, padx=5)
        
        # Variable para almacenar resultados
        self.last_results = None
        
        # Área de resultados (placeholder)
        results_frame = tk.LabelFrame(
            self.main_area,
            text="Resultados",
            font=("Arial", 12, "bold"),
            bg=BG_COLOR,
            padx=20,
            pady=20
        )
        results_frame.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)
        
        self.results_text = tk.Text(
            results_frame,
            font=("Courier", 10),
            wrap=tk.WORD,
            state=tk.DISABLED
        )
        self.results_text.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = tk.Scrollbar(results_frame, command=self.results_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.results_text.config(yscrollcommand=scrollbar.set)
        
    def _show_config_screen(self):
        """Mostrar pantalla de configuración"""
        self._clear_main_area()
        
        # Contenedor principal con scroll
        canvas = tk.Canvas(self.main_area, bg=BG_COLOR, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.main_area, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=BG_COLOR)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Título
        title = tk.Label(
            scrollable_frame,
            text="⚙️ Configuración",
            font=("Arial", 20, "bold"),
            bg=BG_COLOR,
            fg=PRIMARY_COLOR
        )
        title.pack(pady=20)
        
        # Cargar configuración actual
        config = load_user_config()
        
        # Variables para los controles
        self.config_vars = {}
        
        # ========== SECCIÓN 1: UMBRALES ==========
        self._create_config_section(
            scrollable_frame,
            "📊 Umbrales de Análisis",
            "Configura los límites para las reglas de análisis"
        )
        
        # Frame para umbrales
        thresholds_frame = tk.Frame(scrollable_frame, bg=BG_COLOR)
        thresholds_frame.pack(padx=40, pady=10, fill=tk.X)
        
        # Umbral: Actividades máximas por Sequence
        self._create_threshold_input(
            thresholds_frame,
            "max_activities_sequence",
            "Máximo de actividades por Sequence:",
            config.get("thresholds", {}).get("max_activities_sequence", 20),
            "Número máximo de actividades permitidas en un Sequence"
        )
        
        # Umbral: IFs anidados
        self._create_threshold_input(
            thresholds_frame,
            "max_nested_ifs",
            "Máximo de IFs anidados:",
            config.get("thresholds", {}).get("max_nested_ifs", 3),
            "Nivel máximo de anidamiento de IFs permitido"
        )
        
        # Umbral: Código comentado
        self._create_threshold_input(
            thresholds_frame,
            "max_commented_code_percent",
            "Máximo % de código comentado:",
            config.get("thresholds", {}).get("max_commented_code_percent", 5),
            "Porcentaje máximo de código comentado permitido"
        )
        
        # ========== SECCIÓN 2: VALIDACIONES ==========
        self._create_config_section(
            scrollable_frame,
            "✅ Opciones de Validación",
            "Activa o desactiva validaciones específicas"
        )
        
        # Frame para validaciones
        validations_frame = tk.Frame(scrollable_frame, bg=BG_COLOR)
        validations_frame.pack(padx=40, pady=10, fill=tk.X)
        
        # Validaciones opcionales
        self._create_validation_checkbox(
            validations_frame,
            "validate_variable_prefixes",
            "Validar prefijos in_/out_/io_ en argumentos",
            config.get("validations", {}).get("validate_variable_prefixes", True)
        )
        
        self._create_validation_checkbox(
            validations_frame,
            "validate_argument_descriptions",
            "Validar descripciones en argumentos",
            config.get("validations", {}).get("validate_argument_descriptions", True)
        )
        
        self._create_validation_checkbox(
            validations_frame,
            "validate_init_end_pattern",
            "Validar patrón Init/End en States",
            config.get("validations", {}).get("validate_init_end_pattern", False)
        )
        
        # ========== SECCIÓN 3: OPCIONES DE SALIDA ==========
        self._create_config_section(
            scrollable_frame,
            "📄 Opciones de Reportes",
            "Configura el formato y contenido de los reportes"
        )
        
        # Frame para opciones de salida
        output_frame = tk.Frame(scrollable_frame, bg=BG_COLOR)
        output_frame.pack(padx=40, pady=10, fill=tk.X)
        
        # AUTO-GENERACIÓN DE REPORTES (NUEVO)
        self._create_output_checkbox(
            output_frame,
            "auto_generate_reports",
            "✨ Generar reportes automáticamente (recomendado)",
            config.get("output", {}).get("auto_generate_reports", True)
        )
        
        # Nota informativa
        info_frame = tk.Frame(output_frame, bg="#E3F2FD", relief=tk.FLAT, bd=1)
        info_frame.pack(fill=tk.X, pady=(0, 10), padx=20)
        
        info_label = tk.Label(
            info_frame,
            text="ℹ️  Recomendable dejarlo activado para poder acceder siempre al reporte.\n"
                 "   En caso contrario, pulsar 'Generar Reporte' en el análisis.",
            font=("Arial", 8),
            bg="#E3F2FD",
            fg="#1976D2",
            justify=tk.LEFT,
            anchor="w",
            padx=10,
            pady=5
        )
        info_label.pack(fill=tk.X)
        
        # Opciones de formato
        self._create_output_checkbox(
            output_frame,
            "generate_html",
            "Generar reporte HTML",
            config.get("output", {}).get("generate_html", True)
        )
        
        self._create_output_checkbox(
            output_frame,
            "generate_excel",
            "Generar reporte Excel",
            config.get("output", {}).get("generate_excel", False)
        )
        
        self._create_output_checkbox(
            output_frame,
            "include_charts",
            "Incluir gráficos en reportes",
            config.get("output", {}).get("include_charts", True)
        )
        
        # ========== SECCIÓN 4: LOGO PERSONALIZADO ==========
        self._create_config_section(
            scrollable_frame,
            "🎨 Logo Personalizado",
            "Configura el logo que aparece en los reportes"
        )
        
        # Frame para logo
        logo_frame = tk.Frame(scrollable_frame, bg=BG_COLOR)
        logo_frame.pack(padx=40, pady=10, fill=tk.X)
        
        # Label con ruta actual del logo
        logo_path = config.get("custom_logo", "Logo por defecto")
        self.logo_path_label = tk.Label(
            logo_frame,
            text=f"Logo actual: {logo_path}",
            font=("Arial", 10),
            bg=BG_COLOR,
            fg=TEXT_COLOR,
            anchor="w"
        )
        self.logo_path_label.pack(fill=tk.X, pady=5)
        
        # Botones para logo
        logo_buttons_frame = tk.Frame(logo_frame, bg=BG_COLOR)
        logo_buttons_frame.pack(pady=5)
        
        select_logo_btn = tk.Button(
            logo_buttons_frame,
            text="📁 Seleccionar Logo",
            command=self._select_custom_logo,
            bg=PRIMARY_COLOR,
            fg="white",
            font=("Arial", 10),
            relief=tk.FLAT,
            cursor="hand2",
            padx=15,
            pady=5
        )
        select_logo_btn.pack(side=tk.LEFT, padx=5)
        
        reset_logo_btn = tk.Button(
            logo_buttons_frame,
            text="🔄 Restaurar Logo",
            command=self._reset_logo,
            bg=SECONDARY_COLOR,
            fg="white",
            font=("Arial", 10),
            relief=tk.FLAT,
            cursor="hand2",
            padx=15,
            pady=5
        )
        reset_logo_btn.pack(side=tk.LEFT, padx=5)
        
        # ========== BOTONES DE ACCIÓN ==========
        buttons_frame = tk.Frame(scrollable_frame, bg=BG_COLOR)
        buttons_frame.pack(pady=30)
        
        # Botón Guardar
        save_btn = tk.Button(
            buttons_frame,
            text="💾 Guardar Configuración",
            command=self._save_configuration,
            bg=COLOR_SUCCESS,
            fg="white",
            font=("Arial", 12, "bold"),
            relief=tk.FLAT,
            cursor="hand2",
            padx=20,
            pady=10
        )
        save_btn.pack(side=tk.LEFT, padx=10)
        
        # Botón Restaurar Valores por Defecto
        reset_btn = tk.Button(
            buttons_frame,
            text="🔄 Restaurar Valores por Defecto",
            command=self._reset_configuration,
            bg="#FFC107",
            fg="white",
            font=("Arial", 12),
            relief=tk.FLAT,
            cursor="hand2",
            padx=20,
            pady=10
        )
        reset_btn.pack(side=tk.LEFT, padx=10)
        
        # Empaquetar canvas y scrollbar
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Forzar actualización de geometría y scroll
        scrollable_frame.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))
        
    def _create_config_section(self, parent, title, description):
        """Crear sección de configuración con título y descripción"""
        section_frame = tk.Frame(parent, bg=BG_COLOR)
        section_frame.pack(padx=20, pady=(20, 5), fill=tk.X)
        
        # Título de sección
        title_label = tk.Label(
            section_frame,
            text=title,
            font=("Arial", 14, "bold"),
            bg=BG_COLOR,
            fg=PRIMARY_COLOR,
            anchor="w"
        )
        title_label.pack(fill=tk.X)
        
        # Descripción
        desc_label = tk.Label(
            section_frame,
            text=description,
            font=("Arial", 9),
            bg=BG_COLOR,
            fg=TEXT_COLOR,
            anchor="w"
        )
        desc_label.pack(fill=tk.X)
        
        # Línea separadora
        separator = tk.Frame(section_frame, bg=PRIMARY_COLOR, height=2)
        separator.pack(fill=tk.X, pady=5)
        
    def _create_threshold_input(self, parent, key, label_text, default_value, tooltip):
        """Crear input para umbral numérico"""
        row_frame = tk.Frame(parent, bg=BG_COLOR)
        row_frame.pack(fill=tk.X, pady=5)
        
        # Label
        label = tk.Label(
            row_frame,
            text=label_text,
            font=("Arial", 10),
            bg=BG_COLOR,
            fg=TEXT_COLOR,
            width=35,
            anchor="w"
        )
        label.pack(side=tk.LEFT, padx=5)
        
        # Entry
        var = tk.IntVar(value=default_value)
        self.config_vars[key] = var
        
        entry = tk.Entry(
            row_frame,
            textvariable=var,
            font=("Arial", 10),
            width=10
        )
        entry.pack(side=tk.LEFT, padx=5)
        
        # Tooltip
        tooltip_label = tk.Label(
            row_frame,
            text=f"ℹ️ {tooltip}",
            font=("Arial", 8),
            bg=BG_COLOR,
            fg="#666",
            anchor="w"
        )
        tooltip_label.pack(side=tk.LEFT, padx=10)
        
    def _create_validation_checkbox(self, parent, key, label_text, default_value):
        """Crear checkbox para validación"""
        var = tk.BooleanVar(value=default_value)
        self.config_vars[key] = var
        
        checkbox = tk.Checkbutton(
            parent,
            text=label_text,
            variable=var,
            font=("Arial", 10),
            bg=BG_COLOR,
            fg=TEXT_COLOR,
            selectcolor=BG_COLOR,
            activebackground=BG_COLOR,
            anchor="w"
        )
        checkbox.pack(fill=tk.X, pady=3, padx=5)
        
    def _create_output_checkbox(self, parent, key, label_text, default_value):
        """Crear checkbox para opción de salida"""
        var = tk.BooleanVar(value=default_value)
        self.config_vars[key] = var
        
        checkbox = tk.Checkbutton(
            parent,
            text=label_text,
            variable=var,
            font=("Arial", 10),
            bg=BG_COLOR,
            fg=TEXT_COLOR,
            selectcolor=BG_COLOR,
            activebackground=BG_COLOR,
            anchor="w"
        )
        checkbox.pack(fill=tk.X, pady=3, padx=5)
        
    def _select_custom_logo(self):
        """Seleccionar logo personalizado"""
        filetypes = [
            ("Imágenes", "*.png *.jpg *.jpeg *.gif"),
            ("Todos los archivos", "*.*")
        ]
        
        filepath = filedialog.askopenfilename(
            title="Seleccionar Logo",
            filetypes=filetypes
        )
        
        if filepath:
            # Actualizar label
            self.logo_path_label.config(text=f"Logo actual: {filepath}")
            # Guardar en configuración temporal
            self.custom_logo_path = filepath
            messagebox.showinfo(
                "Logo Seleccionado",
                f"Logo seleccionado correctamente.\nNo olvides guardar la configuración."
            )
            
    def _reset_logo(self):
        """Restaurar logo por defecto"""
        self.logo_path_label.config(text="Logo actual: Logo por defecto")
        self.custom_logo_path = None
        messagebox.showinfo(
            "Logo Restaurado",
            "Logo restaurado al valor por defecto.\nNo olvides guardar la configuración."
        )
        
    def _save_configuration(self):
        """Guardar toda la configuración"""
        try:
            # Cargar config actual
            config = load_user_config()
            
            # Actualizar umbrales
            config["thresholds"] = {
                "max_activities_sequence": self.config_vars.get("max_activities_sequence", tk.IntVar(value=20)).get(),
                "max_nested_ifs": self.config_vars.get("max_nested_ifs", tk.IntVar(value=3)).get(),
                "max_commented_code_percent": self.config_vars.get("max_commented_code_percent", tk.IntVar(value=5)).get()
            }
            
            # Actualizar validaciones
            config["validations"] = {
                "validate_variable_prefixes": self.config_vars.get("validate_variable_prefixes", tk.BooleanVar(value=True)).get(),
                "validate_argument_descriptions": self.config_vars.get("validate_argument_descriptions", tk.BooleanVar(value=True)).get(),
                "validate_init_end_pattern": self.config_vars.get("validate_init_end_pattern", tk.BooleanVar(value=False)).get()
            }
            
            # Actualizar opciones de salida
            config["output"] = {
                "auto_generate_reports": self.config_vars.get("auto_generate_reports", tk.BooleanVar(value=True)).get(),
                "generate_html": self.config_vars.get("generate_html", tk.BooleanVar(value=True)).get(),
                "generate_excel": self.config_vars.get("generate_excel", tk.BooleanVar(value=False)).get(),
                "include_charts": self.config_vars.get("include_charts", tk.BooleanVar(value=True)).get()
            }
            
            # Actualizar logo personalizado si se cambió
            if hasattr(self, 'custom_logo_path'):
                config["custom_logo"] = self.custom_logo_path
            
            # Guardar
            if save_user_config(config):
                self.update_status("Configuración guardada correctamente", "success")
            else:
                self.update_status("Error al guardar la configuración", "error")
                
        except Exception as e:
            messagebox.showerror(
                "❌ Error",
                f"Error al guardar la configuración:\n{str(e)}"
            )
            
    def _reset_configuration(self):
        """Restaurar configuración a valores por defecto"""
        confirm = messagebox.askyesno(
            "⚠️ Confirmar Restauración",
            "¿Estás seguro de que quieres restaurar todos los valores por defecto?\n\nEsta acción no se puede deshacer."
        )
        
        if confirm:
            if reset_to_defaults():
                messagebox.showinfo(
                    "✅ Restaurado",
                    "La configuración ha sido restaurada a los valores por defecto.\n\nRecarga la pantalla para ver los cambios."
                )
                # Recargar pantalla
                self._show_config_screen()
            else:
                messagebox.showerror(
                    "❌ Error",
                    "No se pudo restaurar la configuración."
                )
        
    def _show_version_notes(self):
        """Mostrar notas de versión desde CHANGELOG.md"""
        self._clear_main_area()
        
        # Importar y mostrar pantalla de release notes
        from src.ui.release_notes_screen import ReleaseNotesScreen
        
        release_notes = ReleaseNotesScreen(self.main_area)
        release_notes.pack(fill=tk.BOTH, expand=True)
    
    def _show_metrics_dashboard(self):
        """Mostrar dashboard de métricas"""
        self._clear_main_area()
        
        # Importar y mostrar dashboard de métricas
        from src.ui.metrics_dashboard import show_metrics_dashboard
        
        dashboard = show_metrics_dashboard(self.main_area, self.project_path)
        dashboard.pack(fill=tk.BOTH, expand=True)
        
    # ========================================================================
    # FUNCIONES
    # ========================================================================
    
    def _browse_project(self):
        """Abrir diálogo para seleccionar carpeta de proyecto"""
        folder = filedialog.askdirectory(
            title="Seleccionar carpeta de proyecto UiPath"
        )
        if folder:
            self.project_path = Path(folder)
            self.path_entry.delete(0, tk.END)
            self.path_entry.insert(0, str(self.project_path))
            self.update_status(f"Proyecto seleccionado: {self.project_path.name}")
    
    def _start_analysis(self):
        """Iniciar análisis del proyecto"""
        if not self.project_path:
            messagebox.showwarning(
                "Advertencia",
                "Por favor, selecciona una carpeta de proyecto primero"
            )
            return
            
        # Obtener selección de reglas
        selected_set = self.rules_combo.get()
        self.active_sets_for_scan = None
        if selected_set != "Todas":
            self.active_sets_for_scan = [selected_set]
        
        # Importar módulos necesarios
        from src.project_scanner import ProjectScanner
        from src.config import DEFAULT_CONFIG
        import threading
        
        # Limpiar resultados previos
        self.results_text.config(state=tk.NORMAL)
        self.results_text.delete("1.0", tk.END)
        self.results_text.insert("1.0", "Iniciando análisis...\n\n")
        self.results_text.config(state=tk.DISABLED)
        
        # Crear barra de progreso
        self.progress_window = tk.Toplevel(self.root)
        self.progress_window.title("Analizando proyecto...")
        self.progress_window.geometry("500x150")
        self.progress_window.transient(self.root)
        self.progress_window.grab_set()
        
        # Centrar ventana de progreso
        self.progress_window.update_idletasks()
        x = (self.progress_window.winfo_screenwidth() // 2) - (500 // 2)
        y = (self.progress_window.winfo_screenheight() // 2) - (150 // 2)
        self.progress_window.geometry(f"500x150+{x}+{y}")
        
        # Label de archivo actual
        self.progress_label = tk.Label(
            self.progress_window,
            text="Buscando archivos XAML...",
            font=("Arial", 10),
            wraplength=450
        )
        self.progress_label.pack(pady=20)
        
        # Barra de progreso
        self.progress_bar = ttk.Progressbar(
            self.progress_window,
            length=450,
            mode='determinate'
        )
        self.progress_bar.pack(pady=10)
        
        # Label de porcentaje
        self.progress_percent_label = tk.Label(
            self.progress_window,
            text="0%",
            font=("Arial", 10, "bold")
        )
        self.progress_percent_label.pack(pady=5)
        
        # Botón cancelar (por ahora solo cierra)
        cancel_btn = tk.Button(
            self.progress_window,
            text="Cancelar",
            command=self._cancel_analysis
        )
        cancel_btn.pack(pady=10)
        
        self.analysis_cancelled = False
        
        # Función de callback para progreso
        def progress_callback(file_name, percentage):
            if self.analysis_cancelled:
                return
            
            self.progress_label.config(text=f"Analizando: {file_name}")
            self.progress_bar['value'] = percentage
            self.progress_percent_label.config(text=f"{int(percentage)}%")
            self.progress_window.update()
        
        # Función para ejecutar análisis en thread separado
        def run_analysis():
            try:
                # Cargar configuración del usuario (no DEFAULT_CONFIG)
                user_config = load_user_config()
                
                # Obtener reglas seleccionadas (desde el thread principal antes de entrar aquí)
                # Pero como estamos en thread, mejor pasarlo como argumento a run_analysis
                # O leerlo antes. Para simplificar, asumimos que self.selected_rules_set se setea antes
                
                scanner = ProjectScanner(self.project_path, user_config, active_sets=self.active_sets_for_scan)
                results = scanner.scan(progress_callback)
                
                # Al terminar, actualizar UI en el thread principal
                self.root.after(0, lambda: self._show_results(results, scanner))
                
            except Exception as e:
                self.root.after(0, lambda: self._show_error(str(e)))
        
        # Iniciar análisis en thread separado
        analysis_thread = threading.Thread(target=run_analysis, daemon=True)
        analysis_thread.start()
    
    def _cancel_analysis(self):
        """Cancelar análisis en curso"""
        self.analysis_cancelled = True
        if hasattr(self, 'progress_window'):
            self.progress_window.destroy()
        self.update_status("Análisis cancelado por el usuario", "warning")
    
    def _show_results(self, results, scanner):
        """Mostrar resultados del análisis"""
        # Guardar resultados para reporte
        self.last_results = results
        
        # Cargar configuración para verificar opciones de salida
        config = load_user_config()
        output_options = config.get('output', {})
        
        # Habilitar botones según configuración
        if output_options.get('generate_html', True):
            self.report_btn.config(state=tk.NORMAL)
        else:
            self.report_btn.config(state=tk.DISABLED)
        
        if output_options.get('generate_excel', False):
            self.excel_btn.config(state=tk.NORMAL)
        else:
            self.excel_btn.config(state=tk.DISABLED)
        
        # Cerrar ventana de progreso
        if hasattr(self, 'progress_window'):
            self.progress_window.destroy()
        
        if not results.get('success'):
            self._show_error(results.get('error', 'Error desconocido'))
            return
        
        # Actualizar área de resultados
        self.results_text.config(state=tk.NORMAL)
        self.results_text.delete("1.0", tk.END)
        
        # Mostrar resumen
        summary = scanner.get_summary()
        self.results_text.insert("1.0", summary)
        
        # Agregar hallazgos detallados si existen
        findings = results.get('findings', [])
        if findings:
            self.results_text.insert(tk.END, "\n\n" + "="*60 + "\n")
            self.results_text.insert(tk.END, "HALLAZGOS DETALLADOS:\n")
            self.results_text.insert(tk.END, "="*60 + "\n\n")
            
            for idx, finding in enumerate(findings[:50], 1):  # Limitar a 50
                severity_symbol = {
                    'error': '❌',
                    'warning': '⚠️',
                    'info': 'ℹ️'
                }.get(finding['severity'], '•')
                
                self.results_text.insert(
                    tk.END,
                    f"{idx}. {severity_symbol} [{finding['category'].upper()}] "
                    f"{finding['description']}\n"
                )
                self.results_text.insert(
                    tk.END,
                    f"   Archivo: {Path(finding['file_path']).name}\n"
                )
                if finding.get('location'):
                    self.results_text.insert(
                        tk.END,
                        f"   Ubicación: {finding['location']}\n"
                    )
                self.results_text.insert(tk.END, "\n")
            
            if len(findings) > 50:
                self.results_text.insert(
                    tk.END,
                    f"\n... y {len(findings) - 50} hallazgos más.\n"
                )
        
        self.results_text.config(state=tk.DISABLED)
        
        # Actualizar barra de estado
        score = results.get('score', {}).get('score', 0)
        self.update_status(f"Análisis completado - Score: {score}/100. Hallazgos: {results['statistics']['total_findings']}", "success")
        
        # Guardar en base de datos de métricas
        try:
            from src.database.metrics_db import get_metrics_db
            db = get_metrics_db()
            db.save_analysis(results)
        except Exception as e:
            print(f"Error guardando métricas: {e}")
    
    def _generate_report(self):
        """Generar reporte HTML"""
        if not self.last_results:
            messagebox.showwarning(
                "Advertencia",
                "No hay resultados para generar reporte.\nPor favor, analiza un proyecto primero."
            )
            return
        
        try:
            from src.report_generator import HTMLReportGenerator
            from datetime import datetime
            
            # Crear nombre de archivo con timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            project_name = self.last_results['project_info'].get('name', 'proyecto')
            output_file = Path(f"output/reporte_{project_name}_{timestamp}.html")
            
            # Generar reporte
            generator = HTMLReportGenerator(self.last_results, output_file)
            report_path = generator.generate()
            
            # Preguntar si abrir el reporte
            result = messagebox.askyesno(
                "Reporte Generado",
                f"Reporte HTML generado con éxito:\n\n{report_path}\n\n¿Deseas abrirlo ahora?"
            )
            
            if result:
                import webbrowser
                webbrowser.open(str(report_path.absolute()))
            
            self.update_status(f"Reporte generado: {report_path.name}", "success")
            
        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Error al generar el reporte:\n\n{str(e)}"
            )
    
    def _generate_excel_report(self):
        """Generar reporte Excel"""
        if not self.last_results:
            messagebox.showwarning(
                "Advertencia",
                "No hay resultados para generar reporte.\nPor favor, analiza un proyecto primero."
            )
            return
        
        try:
            from src.excel_report_generator import ExcelReportGenerator
            from datetime import datetime
            
            # Crear nombre de archivo con timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            project_name = self.last_results['project_info'].get('name', 'proyecto')
            output_file = Path(f"output/reporte_{project_name}_{timestamp}.xlsx")
            
            # Cargar configuración para gráficos
            config = load_user_config()
            include_charts = config.get('output', {}).get('include_charts', True)
            
            # Generar reporte
            generator = ExcelReportGenerator(
                self.last_results, 
                output_file,
                include_charts=include_charts
            )
            report_path = generator.generate()
            
            # Preguntar si abrir el reporte
            result = messagebox.askyesno(
                "Reporte Excel Generado",
                f"Reporte Excel generado con éxito:\n\n{report_path}\n\n¿Deseas abrirlo ahora?"
            )
            
            if result:
                import os
                os.startfile(str(report_path.absolute()))
            
            self.status_bar.config(text=f"Reporte Excel generado: {report_path.name}")
            
        except ImportError:
            messagebox.showerror(
                "Error",
                "No se pudo importar el generador de Excel.\n\n"
                "Asegúrate de tener instalado: pip install openpyxl"
            )
        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Error al generar el reporte Excel:\n\n{str(e)}"
            )
    
    def _show_error(self, error_message):
        """Mostrar error en el análisis"""
        if hasattr(self, 'progress_window'):
            self.progress_window.destroy()
        
        self.results_text.config(state=tk.NORMAL)
        self.results_text.delete("1.0", tk.END)
        self.results_text.insert("1.0", f"ERROR: {error_message}\n")
        self.results_text.config(state=tk.DISABLED)
        
        self.status_bar.config(text="Error en el análisis")
        
        messagebox.showerror(
            "Error",
            f"Error durante el análisis:\n\n{error_message}"
        )
    
    # ========================================================================
    # GESTIÓN DE CONJUNTOS DE BBPP
    # ========================================================================
    
    def _show_bbpp_management_screen(self):
        """Mostrar pantalla de gestión de reglas BBPP"""
        # Limpiar área principal
        for widget in self.main_area.winfo_children():
            widget.destroy()
        
        # Importar y crear pantalla de gestión de reglas
        try:
            from src.ui.rules_management_screen import RulesManagementScreen
            RulesManagementScreen(self.main_area)
        except Exception as e:
            # Si falla, mostrar mensaje de error
            import traceback
            error_frame = tk.Frame(self.main_area, bg=BG_COLOR)
            error_frame.pack(fill=tk.BOTH, expand=True)
            
            error_text = f"❌ Error al cargar Gestión de Reglas:\n\n{str(e)}\n\n{traceback.format_exc()}"
            error_label = tk.Label(
                error_frame,
                text=error_text,
                font=("Arial", 10),
                bg=BG_COLOR,
                fg=COLOR_ERROR,
                justify=tk.LEFT
            )
            error_label.pack(pady=20, padx=20)
    

    def _save_bbpp_configuration(self):
        """Guardar configuración de conjuntos activos"""
        # Obtener conjuntos activos
        active_sets = [
            filename for filename, var in self.bbpp_checkboxes.items()
            if var.get()
        ]
        
        # Guardar en config
        from src.config import set_active_bbpp_sets
        
        if set_active_bbpp_sets(active_sets):
            messagebox.showinfo(
                "Configuración Guardada",
                f"✅ Se han activado {len(active_sets)} conjunto(s) de BBPP.\n\n"
                "Los cambios se aplicarán en el próximo análisis."
            )
            self.status_bar.config(text=f"Configuración guardada: {len(active_sets)} conjunto(s) activo(s)")
        else:
            messagebox.showerror(
                "Error",
                "❌ No se pudo guardar la configuración.\n\n"
                "Verifica los permisos de escritura en config/user_config.json"
            )
    
    def _export_bbpp_set(self):
        """Exportar un conjunto de BBPP individual"""
        from src.config import get_available_bbpp_sets, export_bbpp_set
        
        # Obtener conjuntos disponibles
        available_sets = get_available_bbpp_sets()
        
        if not available_sets:
            messagebox.showwarning(
                "Sin Conjuntos",
                "No hay conjuntos disponibles para exportar"
            )
            return
        
        # Crear ventana de selección
        select_window = tk.Toplevel(self.root)
        select_window.title("Seleccionar Conjunto a Exportar")
        select_window.geometry("500x400")
        select_window.transient(self.root)
        select_window.grab_set()
        
        # Centrar ventana
        select_window.update_idletasks()
        x = (select_window.winfo_screenwidth() // 2) - (500 // 2)
        y = (select_window.winfo_screenheight() // 2) - (400 // 2)
        select_window.geometry(f"500x400+{x}+{y}")
        
        # Título
        tk.Label(
            select_window,
            text="Selecciona el conjunto a exportar:",
            font=("Arial", 12, "bold"),
            pady=15
        ).pack()
        
        # Lista de conjuntos
        selected_set = tk.StringVar()
        
        list_frame = tk.Frame(select_window)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        listbox = tk.Listbox(
            list_frame,
            font=("Arial", 10),
            yscrollcommand=scrollbar.set,
            selectmode=tk.SINGLE
        )
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=listbox.yview)
        
        # Agregar conjuntos a la lista
        for bbpp_set in available_sets:
            display_text = f"{bbpp_set['name']} ({bbpp_set['filename']}) - {bbpp_set['rules_count']} reglas"
            listbox.insert(tk.END, display_text)
        
        def do_export():
            selection = listbox.curselection()
            if not selection:
                messagebox.showwarning("Advertencia", "Por favor, selecciona un conjunto")
                return
            
            selected_index = selection[0]
            bbpp_set = available_sets[selected_index]
            
            # Pedir ubicación de guardado
            from tkinter import filedialog
            filename = filedialog.asksaveasfilename(
                title="Guardar conjunto como",
                defaultextension=".json",
                initialfile=bbpp_set['filename'],
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if filename:
                from pathlib import Path
                if export_bbpp_set(Path(bbpp_set['filepath']), Path(filename)):
                    select_window.destroy()
                    messagebox.showinfo(
                        "Exportación Exitosa",
                        f"✅ Conjunto exportado correctamente a:\n{filename}"
                    )
                else:
                    messagebox.showerror(
                        "Error",
                        "❌ No se pudo exportar el conjunto"
                    )
        
        # Botones
        btn_frame = tk.Frame(select_window)
        btn_frame.pack(pady=10)
        
        tk.Button(
            btn_frame,
            text="📤 Exportar",
            command=do_export,
            bg="#28A745",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=8
        ).pack(side=tk.LEFT, padx=5)
        
        tk.Button(
            btn_frame,
            text="Cancelar",
            command=select_window.destroy,
            bg="#6C757D",
            fg="white",
            font=("Arial", 10),
            padx=20,
            pady=8
        ).pack(side=tk.LEFT, padx=5)
    
    def _import_bbpp_set(self):
        """Importar un conjunto de BBPP desde archivo"""
        from src.config import import_bbpp_set
        from tkinter import filedialog
        from pathlib import Path
        
        # Pedir archivo a importar
        filename = filedialog.askopenfilename(
            title="Seleccionar archivo JSON a importar",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if not filename:
            return
        
        # Confirmar importación
        response = messagebox.askyesno(
            "Confirmar Importación",
            f"¿Importar el conjunto desde:\n{Path(filename).name}?\n\n"
            "Si ya existe un archivo con el mismo nombre, se creará un backup automático."
        )
        
        if not response:
            return
        
        # Importar
        if import_bbpp_set(Path(filename)):
            messagebox.showinfo(
                "Importación Exitosa",
                f"✅ Conjunto importado correctamente.\n\n"
                "El nuevo conjunto ya está disponible en config/bbpp/\n"
                "Recarga esta pantalla para verlo en la lista."
            )
            # Recargar pantalla
            self._show_bbpp_management_screen()
        else:
            messagebox.showerror(
                "Error",
                "❌ No se pudo importar el conjunto.\n\n"
                "Verifica que el archivo JSON tenga el formato correcto."
            )
    
    def _export_all_configuration(self):
        """Exportar configuración completa (todos los conjuntos activos)"""
        from src.config import export_all_active_bbpp
        from tkinter import filedialog
        from pathlib import Path
        from datetime import datetime
        
        # Nombre por defecto con timestamp
        default_name = f"BBPP_Config_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Pedir ubicación de guardado
        filename = filedialog.asksaveasfilename(
            title="Guardar configuración completa como",
            defaultextension=".json",
            initialfile=default_name,
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if not filename:
            return
        
        # Exportar
        if export_all_active_bbpp(Path(filename)):
            messagebox.showinfo(
                "Exportación Exitosa",
                f"✅ Configuración completa exportada a:\n{Path(filename).name}\n\n"
                "Incluye todos los conjuntos activos y sus reglas."
            )
        else:
            messagebox.showerror(
                "Error",
                "❌ No se pudo exportar la configuración.\n\n"
                "Verifica que haya al menos un conjunto activo."
            )
    
    def run(self):
        """Ejecutar la aplicación"""
        self.root.mainloop()


if __name__ == "__main__":
    app = MainWindow()
    app.run()
